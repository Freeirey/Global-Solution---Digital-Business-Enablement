CREATE TABLE task (
	id bigint PRIMARY KEY auto_increment,
	title varchar(200),
	description TEXT,
	points int,
	status int DEFAULT 0,
	user_id int
);

CREATE TABLE user (
	id bigint PRIMARY KEY auto_increment,
	name varchar(200),
	email varchar(200),
	password varchar(200),
	githubuser varchar(200)
);

CREATE TABLE ROLE (
	id int primary key auto_increment,
	name varchar(200)
);

CREATE TABLE user_roles(
	user_id int,
	roles_id int
);

INSERT INTO role (name) VALUES ('ROLE_ADMIN'), ('ROLE_USER');

INSERT INTO user (name, email, password, githubuser) VALUES
('Joao Carlos', 'joao@gmail.com', '$2a$12$QyF4w1FII8opXmjlEX53PuK45.a8MBQI40c7kbQ9o5y1fbUKwHrfW', 'joaocarloslima'),
('Carla Lopes', 'carla@gmail.com', '$2a$12$QyF4w1FII8opXmjlEX53PuK45.a8MBQI40c7kbQ9o5y1fbUKwHrfW', 'carla'),
('Fabio Cabrini', 'fabio@fiap.com.br', '$2a$12$QyF4w1FII8opXmjlEX53PuK45.a8MBQI40c7kbQ9o5y1fbUKwHrfW', 'fabio');

INSERT INTO user_roles VALUES (1,1), (2,2), (3,2);

INSERT INTO task (title, description, points, status, user_id) VALUES (
	'Criar banco de dados',
	'Criação do banco de dados Oracle',
	50,
	10,
	1
);

INSERT INTO task (title, description, points, status) VALUES (
	'Análise de dados',
	'Análisar os dados da aplicação web',
	20,
	50
);

INSERT INTO task (title, description, points, status, user_id) VALUES (
	'Análise de usabilidade',
	'Planejar teste A-B da interface gráfica',
	30,
	90,
	2
);